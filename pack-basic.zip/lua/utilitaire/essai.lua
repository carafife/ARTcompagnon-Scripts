#!/usr/bin/env lua

-- Affiche "coucou" et demande si l'utilisateur veut quitter
print("coucou")
io.write("Veux-tu quitter ? (oui/non) : ")
local reponse = io.read()

if reponse and reponse:lower() == "oui" then
    print("Au revoir !")
    os.exit()
else
    print("D'accord, le programme continue.")
end
