# Programme : devine mon âge (avec gestion des erreurs)
mon_age = 35
continuer = True

print("🎯 Devine mon âge !")
print("J'ai un âge entre 0 et 50 ans")
print("Tape 'quitter' pour arrêter")
print("Tape n'importe quel nombre\n")

while continuer:
    reponse = input("Quel âge tu me donnes ? ")
    
    if reponse == "quitter":
        print(f"Dommage ! Mon âge était {mon_age}. À bientôt !")
        continuer = False
    
    else:
        # ESSAYE de faire ce bloc
        try:
            age_utilisateur = int(reponse)
            ecart = abs(age_utilisateur - mon_age)
            
            if ecart == 0:
                print("🎉 BRAVO ! Tu as trouvé mon âge ! 🎉\n")
                continuer = False
            elif ecart <= 2:
                print(f"🔥 Presque ! Tu étais à {ecart} an(s) près.\n")
            elif age_utilisateur < mon_age:
                print(f"📈 Non, {age_utilisateur} est trop petit. Je suis plus âgé(e).\n")
            elif age_utilisateur > mon_age:
                print(f"📉 Non, {age_utilisateur} est trop grand. Je suis plus jeune.\n")
        
        # SI UNE ERREUR SE PRODUIT, on fait ce bloc
        except ValueError:
            print("❌ Ce n'est pas un nombre valide ! Tape un nombre ou 'quitter'.\n")
